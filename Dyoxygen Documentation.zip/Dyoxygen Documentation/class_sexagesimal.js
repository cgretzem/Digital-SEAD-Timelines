var class_sexagesimal =
[
    [ "Sexagesimal", "class_sexagesimal.html#a25dc959ee4d3b1954074e1f4cb0873ab", null ],
    [ "Sexagesimal", "class_sexagesimal.html#af8cffb5cfa5cddb74db7d2eaf29c8ca9", null ],
    [ "operator+", "class_sexagesimal.html#af8794e7fe5ae51f68540ddb8c5367f38", null ],
    [ "operator-", "class_sexagesimal.html#a55e0a3227a957105132a75499a8a2a55", null ],
    [ "print", "class_sexagesimal.html#a56e665dbf8b544ed92972880dfe2099e", null ],
    [ "convertToBase60", "class_sexagesimal.html#aec1fe41bdfd9916f1b023193f2cd1631", null ],
    [ "operator<", "class_sexagesimal.html#a4ba5352fd7c4d80edc3d313c98f96db7", null ],
    [ "operator<<", "class_sexagesimal.html#aa5853eba3fb1a47ca9930a961287f9c0", null ],
    [ "operator<=", "class_sexagesimal.html#a75c3b043d16d7b7cf525297fa03f04cc", null ],
    [ "operator==", "class_sexagesimal.html#a6ef695b7fe5894a2f704cde79f94de19", null ],
    [ "operator>", "class_sexagesimal.html#ac40602c3186e0425b1cd95b51be03d02", null ],
    [ "operator>=", "class_sexagesimal.html#a9f10747e54fb44e0958afe1efde1e92f", null ]
];