var annotated_dup =
[
    [ "fireRange", "structfire_range.html", "structfire_range" ],
    [ "NonStandard_Timeline", "class_non_standard___timeline.html", "class_non_standard___timeline" ],
    [ "Sexagesimal", "class_sexagesimal.html", "class_sexagesimal" ],
    [ "shell", "structshell.html", "structshell" ],
    [ "Standard_Timeline", "class_standard___timeline.html", "class_standard___timeline" ],
    [ "Timeline", "class_timeline.html", "class_timeline" ]
];