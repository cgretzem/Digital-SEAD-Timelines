var structfire_range =
[
    [ "endMin", "structfire_range.html#a20189f1ab55ac6c01b01317d5705362f", null ],
    [ "startMin", "structfire_range.html#a17742a1cb5a456595cd92f7fad0d731b", null ]
];