var hierarchy =
[
    [ "fireRange", "structfire_range.html", null ],
    [ "Sexagesimal", "class_sexagesimal.html", null ],
    [ "shell", "structshell.html", null ],
    [ "Timeline", "class_timeline.html", [
      [ "NonStandard_Timeline", "class_non_standard___timeline.html", null ],
      [ "Standard_Timeline", "class_standard___timeline.html", null ]
    ] ]
];